(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_cc42ff.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_cc42ff.js",
  "chunks": [
    "static/chunks/_dec3f2._.js"
  ],
  "source": "dynamic"
});
