(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_generate_page_a11616.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_generate_page_a11616.js",
  "chunks": [
    "static/chunks/_24178c._.js",
    "static/chunks/node_modules_react-toastify_dist_ReactToastify_391de2.css"
  ],
  "source": "dynamic"
});
