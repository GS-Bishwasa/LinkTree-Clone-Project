(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_[handle]_page_a11616.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_[handle]_page_a11616.js",
  "chunks": [
    "static/chunks/app_[handle]_page_2ce914.js"
  ],
  "source": "dynamic"
});
